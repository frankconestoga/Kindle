﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ch08Cart
{
    public partial class CheckOut : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                rblContact.SelectedValue = "Email";
                lblMessage.Text = string.Empty;
            }
        }

        protected void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid)
            {
                return;
            }

            CartItemList.GetCart().Clear();
            ClearForm();
            lblMessage.Text = "Order Placed";
        }

        protected void btnCancelOrder_Click(object sender, EventArgs e)
        {
            ClearForm();
            Response.Redirect("Cart.aspx");
        }

        protected void btnContinueShopping_Click(object sender, EventArgs e)
        {
            Response.Redirect("Products.aspx");
        }

        private void ClearForm()
        {
            txtEmail.Text = string.Empty;
            txtEmailConfirm.Text = string.Empty;
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
            txtPhone.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtCity.Text = string.Empty;
            txtZip.Text = string.Empty;
            ddlState.SelectedIndex = 0;

            chkNewProducts.Checked = false;
            chkNewEditions.Checked = false;
            chkSpecialOffers.Checked = false;
            chkLocalEvents.Checked = false;
            rblContact.SelectedValue = "Email";

            calDob.SelectedDates.Clear();
            calDob.VisibleDate = DateTime.Today;
        }
    }
}