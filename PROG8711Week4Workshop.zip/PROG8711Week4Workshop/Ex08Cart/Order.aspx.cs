﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// make sure to include these namespaces
using System.Data;
using System.Web.Caching;

namespace Ch08Cart
{
    public partial class Order : System.Web.UI.Page
    {
        private Book selectedBook;

        protected void Page_Load(object sender, EventArgs e)
        {
            // bind drop-down list and update page hit count on first load  
            if (!IsPostBack)
            {
                ddlProducts.DataBind();

            }
            // get and show product data on every load  
            selectedBook = this.GetSelectedBook();
            lblName.Text = selectedBook.Title;
            lblShortDescription.Text = selectedBook.ShortDescription; 
            lblLongDescription.Text = selectedBook.LongDescription;
            lblUnitPrice.Text = selectedBook.Price.ToString("c") + " each";
            imgProduct.ImageUrl = "Images/Products/" + selectedBook.ImageFile;
 
        }

        private Book GetSelectedBook()
        {
            //get row from AccessDataSource based on value in dropdownlist
            DataView productsTable = (DataView)
                SqlDataSource1.Select(DataSourceSelectArguments.Empty);
            productsTable.RowFilter =
                "ProductID = '" + ddlProducts.SelectedValue + "'";
            DataRowView row = productsTable[0];

            //create a new product object and load with data from row
            Book book = new Book();
            book.BookID = row["ProductID"].ToString();
            book.Title = row["Name"].ToString();
            book.ShortDescription = row["ShortDescription"].ToString();
            book.LongDescription = row["LongDescription"].ToString();
            book.Price = (decimal)row["UnitPrice"];
            book.ImageFile = row["ImageFile"].ToString();
            return book;
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                //get cart from session and selected item from cart
                CartItemList cart = CartItemList.GetCart();
                CartItem cartItem = cart[selectedBook.BookID];

                //if item isn’t in cart, add it; otherwise, increase its quantity
                if (cartItem == null)
                {
                    cart.AddItem(selectedBook,
                                 Convert.ToInt32(txtQuantity.Text));
                }
                else
                {
                    cartItem.AddQuantity(Convert.ToInt32(txtQuantity.Text));
                }
                Response.Redirect("Cart.aspx");
            }
        }
    }
}